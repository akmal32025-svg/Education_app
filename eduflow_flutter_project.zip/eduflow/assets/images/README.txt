EduFlow Assets Folder
Place your image assets here:
- logo.png (app logo)
- placeholder_course.png (default course thumbnail)
- placeholder_avatar.png (default user avatar)
