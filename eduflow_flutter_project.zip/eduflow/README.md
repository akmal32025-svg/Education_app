# EduFlow — Firebase Setup & Run Guide

## 📋 Prerequisites

- Flutter SDK 3.0+ installed
- Dart SDK 3.0+
- Android Studio or VS Code
- Firebase account (free tier works)
- Node.js (for Firebase CLI)

---

## 🔥 Step 1: Create Firebase Project

1. Go to https://console.firebase.google.com
2. Click **Add Project** → Name it `EduFlow`
3. Enable Google Analytics (optional)

---

## 🔐 Step 2: Enable Firebase Services

In Firebase Console, enable:

### Authentication
- Go to **Authentication** → **Sign-in method**
- Enable **Email/Password**

### Firestore Database
- Go to **Firestore Database** → **Create database**
- Start in **production mode**
- Choose a region close to your users

### Firebase Storage
- Go to **Storage** → **Get started**
- Start in **production mode**

---

## 📱 Step 3: Add Android App

1. In Firebase Console → **Project Settings** → **Add app** → Android
2. Package name: `com.eduflow.app`
3. Download `google-services.json`
4. Place it in: `android/app/google-services.json`

---

## ⚡ Step 4: Configure Flutter

Install FlutterFire CLI:
```bash
dart pub global activate flutterfire_cli
```

Run configuration:
```bash
flutterfire configure --project=your-firebase-project-id
```

This generates `lib/firebase_options.dart`.

Then update `lib/main.dart` — replace:
```dart
await Firebase.initializeApp();
```
with:
```dart
await Firebase.initializeApp(
  options: DefaultFirebaseOptions.currentPlatform,
);
```
And add import:
```dart
import 'firebase_options.dart';
```

---

## 🔒 Step 5: Firestore Security Rules

In Firebase Console → **Firestore** → **Rules**, paste:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Users can read/write their own profile
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == userId;
    }

    // Anyone authenticated can read courses
    match /courses/{courseId} {
      allow read: if request.auth != null;
      // Only the teacher who owns the course can write
      allow create: if request.auth != null
        && request.resource.data.teacherId == request.auth.uid;
      allow update, delete: if request.auth != null
        && resource.data.teacherId == request.auth.uid;
    }

    // Lectures: teachers write, enrolled students read
    match /lectures/{lectureId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }

    // Attachments
    match /attachments/{attachmentId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }

    // Course access — admin grants access manually
    match /course_access/{docId} {
      allow read: if request.auth != null
        && (resource.data.studentId == request.auth.uid
            || request.auth.uid in ['ADMIN_UID_HERE']);
      allow create: if request.auth != null
        && request.resource.data.studentId == request.auth.uid;
      // Only admin can set hasAccess = true
      allow update: if request.auth.uid in ['ADMIN_UID_HERE'];
    }

    // Watch progress
    match /watch_progress/{docId} {
      allow read, write: if request.auth != null
        && resource.data.studentId == request.auth.uid;
      allow create: if request.auth != null;
    }
  }
}
```

---

## 🗄️ Step 6: Firebase Storage Rules

In Firebase Console → **Storage** → **Rules**:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {

    // Video lectures — authenticated users can read (stream)
    // 🔐 No direct download URL exposed to untrusted clients
    match /lectures/{courseId}/{lectureId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }

    // Course thumbnails
    match /course_thumbnails/{courseId} {
      allow read;
      allow write: if request.auth != null;
    }

    // Attachments
    match /attachments/{courseId}/{fileName} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
  }
}
```

---

## 💬 Step 7: Configure Telegram Admin Link

In `lib/screens/student/course_detail_screen.dart`, update:
```dart
const telegramUsername = 'YourAdminUsername'; // ← Replace with your Telegram username
```

---

## 🚀 Step 8: Run the App

```bash
# Install dependencies
flutter pub get

# Run on connected device/emulator
flutter run

# Run in release mode
flutter run --release
```

---

## 📦 Step 9: Build APK

```bash
# Debug APK
flutter build apk

# Release APK (smaller, optimized)
flutter build apk --release

# Split APKs by ABI (smaller per-device size)
flutter build apk --split-per-abi --release
```

APK output location:
```
build/app/outputs/flutter-apk/app-release.apk
```

---

## 👑 Step 10: Grant Course Access (Admin)

To manually activate a student's course access in Firestore:

1. Go to Firebase Console → **Firestore**
2. Navigate to collection: `course_access`
3. Find document: `{studentId}_{courseId}`
4. Set `hasAccess: true`

---

## 🏗️ Project Structure

```
lib/
├── main.dart                    # App entry, theme, Firebase init
├── models/
│   ├── user_model.dart          # User data model
│   ├── course_model.dart        # Course data model
│   └── lecture_model.dart       # Lecture, Attachment, Progress models
├── services/
│   ├── auth_service.dart        # Firebase Auth + device security
│   └── course_service.dart      # Firestore + Storage operations
├── screens/
│   ├── splash_screen.dart
│   ├── login_screen.dart
│   ├── register_screen.dart
│   ├── teachers_list_screen.dart
│   ├── teacher_profile_screen.dart
│   ├── student/
│   │   ├── student_home_screen.dart
│   │   ├── course_detail_screen.dart
│   │   └── video_player_screen.dart
│   └── teacher/
│       ├── teacher_dashboard_screen.dart
│       ├── create_course_screen.dart
│       ├── teacher_course_screen.dart
│       └── upload_lecture_screen.dart
└── widgets/
    └── course_card.dart         # Reusable course card
```

---

## 🔐 Security Features Summary

| Feature | Implementation |
|---|---|
| Screenshot/recording blocked | `FlutterWindowManager.FLAG_SECURE` applied at app launch |
| Single-device login | Device ID stored in Firestore, checked on every login |
| Secure video streaming | Videos streamed from Firebase Storage, no download button |
| Access control | `course_access` collection checked before showing video player |
| Auth state | Firebase Auth with secure session management |

---

## 🛠️ Troubleshooting

**Build fails with multidex error:**
```
android:name="androidx.multidex.MultiDexApplication"
```
Add to `android/app/build.gradle` → `defaultConfig`: `multiDexEnabled true`

**flutter_windowmanager not found:**
Ensure `minSdk 21` in `android/app/build.gradle`

**Firebase not initialized:**
Ensure `google-services.json` is in `android/app/` and `flutterfire configure` was run.
