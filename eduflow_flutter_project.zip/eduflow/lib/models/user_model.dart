import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents a user in the EduFlow platform
class UserModel {
  final String uid;
  final String email;
  final String displayName;
  final String role; // 'student' | 'teacher'
  final String? photoUrl;
  final String? bio;
  final String? subject; // For teachers
  final String deviceId; // For single-device security
  final DateTime createdAt;
  final bool isActive;

  const UserModel({
    required this.uid,
    required this.email,
    required this.displayName,
    required this.role,
    this.photoUrl,
    this.bio,
    this.subject,
    required this.deviceId,
    required this.createdAt,
    this.isActive = true,
  });

  bool get isTeacher => role == 'teacher';
  bool get isStudent => role == 'student';

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: doc.id,
      email: data['email'] ?? '',
      displayName: data['displayName'] ?? '',
      role: data['role'] ?? 'student',
      photoUrl: data['photoUrl'],
      bio: data['bio'],
      subject: data['subject'],
      deviceId: data['deviceId'] ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isActive: data['isActive'] ?? true,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'email': email,
        'displayName': displayName,
        'role': role,
        'photoUrl': photoUrl,
        'bio': bio,
        'subject': subject,
        'deviceId': deviceId,
        'createdAt': Timestamp.fromDate(createdAt),
        'isActive': isActive,
      };

  UserModel copyWith({
    String? displayName,
    String? photoUrl,
    String? bio,
    String? subject,
    String? deviceId,
    bool? isActive,
  }) =>
      UserModel(
        uid: uid,
        email: email,
        displayName: displayName ?? this.displayName,
        role: role,
        photoUrl: photoUrl ?? this.photoUrl,
        bio: bio ?? this.bio,
        subject: subject ?? this.subject,
        deviceId: deviceId ?? this.deviceId,
        createdAt: createdAt,
        isActive: isActive ?? this.isActive,
      );
}
