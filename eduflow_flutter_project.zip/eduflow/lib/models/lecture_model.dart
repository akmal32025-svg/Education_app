import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents a video lecture within a course
class LectureModel {
  final String id;
  final String courseId;
  final String title;
  final String? description;
  final String videoUrl;
  final int durationSeconds;
  final int orderIndex;
  final DateTime createdAt;
  final bool isPublished;

  const LectureModel({
    required this.id,
    required this.courseId,
    required this.title,
    this.description,
    required this.videoUrl,
    this.durationSeconds = 0,
    required this.orderIndex,
    required this.createdAt,
    this.isPublished = true,
  });

  String get formattedDuration {
    final minutes = durationSeconds ~/ 60;
    final seconds = durationSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  factory LectureModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return LectureModel(
      id: doc.id,
      courseId: data['courseId'] ?? '',
      title: data['title'] ?? '',
      description: data['description'],
      videoUrl: data['videoUrl'] ?? '',
      durationSeconds: data['durationSeconds'] ?? 0,
      orderIndex: data['orderIndex'] ?? 0,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isPublished: data['isPublished'] ?? true,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'courseId': courseId,
        'title': title,
        'description': description,
        'videoUrl': videoUrl,
        'durationSeconds': durationSeconds,
        'orderIndex': orderIndex,
        'createdAt': Timestamp.fromDate(createdAt),
        'isPublished': isPublished,
      };
}

/// Represents a PDF or file attachment in a course
class AttachmentModel {
  final String id;
  final String courseId;
  final String title;
  final String fileUrl;
  final String fileType; // 'pdf' | 'doc' | etc.
  final int fileSizeBytes;
  final DateTime createdAt;

  const AttachmentModel({
    required this.id,
    required this.courseId,
    required this.title,
    required this.fileUrl,
    required this.fileType,
    this.fileSizeBytes = 0,
    required this.createdAt,
  });

  String get formattedSize {
    if (fileSizeBytes < 1024) return '$fileSizeBytes B';
    if (fileSizeBytes < 1048576) {
      return '${(fileSizeBytes / 1024).toStringAsFixed(1)} KB';
    }
    return '${(fileSizeBytes / 1048576).toStringAsFixed(1)} MB';
  }

  factory AttachmentModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return AttachmentModel(
      id: doc.id,
      courseId: data['courseId'] ?? '',
      title: data['title'] ?? '',
      fileUrl: data['fileUrl'] ?? '',
      fileType: data['fileType'] ?? 'pdf',
      fileSizeBytes: data['fileSizeBytes'] ?? 0,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() => {
        'courseId': courseId,
        'title': title,
        'fileUrl': fileUrl,
        'fileType': fileType,
        'fileSizeBytes': fileSizeBytes,
        'createdAt': Timestamp.fromDate(createdAt),
      };
}

/// Tracks which lectures a student has watched
class WatchProgressModel {
  final String id;
  final String studentId;
  final String lectureId;
  final String courseId;
  final int watchedSeconds;
  final bool isCompleted;
  final DateTime lastWatched;

  const WatchProgressModel({
    required this.id,
    required this.studentId,
    required this.lectureId,
    required this.courseId,
    this.watchedSeconds = 0,
    this.isCompleted = false,
    required this.lastWatched,
  });

  factory WatchProgressModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return WatchProgressModel(
      id: doc.id,
      studentId: data['studentId'] ?? '',
      lectureId: data['lectureId'] ?? '',
      courseId: data['courseId'] ?? '',
      watchedSeconds: data['watchedSeconds'] ?? 0,
      isCompleted: data['isCompleted'] ?? false,
      lastWatched:
          (data['lastWatched'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() => {
        'studentId': studentId,
        'lectureId': lectureId,
        'courseId': courseId,
        'watchedSeconds': watchedSeconds,
        'isCompleted': isCompleted,
        'lastWatched': Timestamp.fromDate(lastWatched),
      };
}

/// Tracks course access granted to a student
class CourseAccessModel {
  final String id;
  final String studentId;
  final String courseId;
  final bool hasAccess;
  final DateTime grantedAt;
  final String grantedBy; // admin uid or 'manual'

  const CourseAccessModel({
    required this.id,
    required this.studentId,
    required this.courseId,
    required this.hasAccess,
    required this.grantedAt,
    required this.grantedBy,
  });

  factory CourseAccessModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return CourseAccessModel(
      id: doc.id,
      studentId: data['studentId'] ?? '',
      courseId: data['courseId'] ?? '',
      hasAccess: data['hasAccess'] ?? false,
      grantedAt:
          (data['grantedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      grantedBy: data['grantedBy'] ?? 'manual',
    );
  }

  Map<String, dynamic> toFirestore() => {
        'studentId': studentId,
        'courseId': courseId,
        'hasAccess': hasAccess,
        'grantedAt': Timestamp.fromDate(grantedAt),
        'grantedBy': grantedBy,
      };
}
