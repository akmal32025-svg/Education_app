import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents a course on the platform
class CourseModel {
  final String id;
  final String title;
  final String description;
  final String teacherId;
  final String teacherName;
  final String? thumbnailUrl;
  final List<String> tags;
  final int enrolledCount;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPublished;

  const CourseModel({
    required this.id,
    required this.title,
    required this.description,
    required this.teacherId,
    required this.teacherName,
    this.thumbnailUrl,
    this.tags = const [],
    this.enrolledCount = 0,
    required this.createdAt,
    required this.updatedAt,
    this.isPublished = true,
  });

  factory CourseModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return CourseModel(
      id: doc.id,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      teacherId: data['teacherId'] ?? '',
      teacherName: data['teacherName'] ?? '',
      thumbnailUrl: data['thumbnailUrl'],
      tags: List<String>.from(data['tags'] ?? []),
      enrolledCount: data['enrolledCount'] ?? 0,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isPublished: data['isPublished'] ?? true,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'title': title,
        'description': description,
        'teacherId': teacherId,
        'teacherName': teacherName,
        'thumbnailUrl': thumbnailUrl,
        'tags': tags,
        'enrolledCount': enrolledCount,
        'createdAt': Timestamp.fromDate(createdAt),
        'updatedAt': Timestamp.fromDate(updatedAt),
        'isPublished': isPublished,
      };

  CourseModel copyWith({
    String? title,
    String? description,
    String? thumbnailUrl,
    List<String>? tags,
    int? enrolledCount,
    bool? isPublished,
  }) =>
      CourseModel(
        id: id,
        title: title ?? this.title,
        description: description ?? this.description,
        teacherId: teacherId,
        teacherName: teacherName,
        thumbnailUrl: thumbnailUrl ?? this.thumbnailUrl,
        tags: tags ?? this.tags,
        enrolledCount: enrolledCount ?? this.enrolledCount,
        createdAt: createdAt,
        updatedAt: DateTime.now(),
        isPublished: isPublished ?? this.isPublished,
      );
}
