import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/course_model.dart';
import '../models/lecture_model.dart';

/// Manages all course, lecture, attachment, and access operations
class CourseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final _uuid = const Uuid();

  // ─── Courses ──────────────────────────────────────────────────────────────────

  /// Stream all published courses
  Stream<List<CourseModel>> getCoursesStream() {
    return _db
        .collection('courses')
        .where('isPublished', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(CourseModel.fromFirestore).toList());
  }

  /// Stream courses for a specific teacher
  Stream<List<CourseModel>> getTeacherCoursesStream(String teacherId) {
    return _db
        .collection('courses')
        .where('teacherId', isEqualTo: teacherId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(CourseModel.fromFirestore).toList());
  }

  /// Get a single course by ID
  Future<CourseModel?> getCourseById(String courseId) async {
    try {
      final doc = await _db.collection('courses').doc(courseId).get();
      if (!doc.exists) return null;
      return CourseModel.fromFirestore(doc);
    } catch (e) {
      debugPrint('Error fetching course: $e');
      return null;
    }
  }

  /// Create a new course
  Future<String?> createCourse({
    required String title,
    required String description,
    required String teacherId,
    required String teacherName,
    File? thumbnailFile,
  }) async {
    try {
      final courseId = _uuid.v4();
      String? thumbnailUrl;

      // Upload thumbnail if provided
      if (thumbnailFile != null) {
        thumbnailUrl = await _uploadFile(
          file: thumbnailFile,
          path: 'course_thumbnails/$courseId.jpg',
          contentType: 'image/jpeg',
        );
      }

      final course = CourseModel(
        id: courseId,
        title: title,
        description: description,
        teacherId: teacherId,
        teacherName: teacherName,
        thumbnailUrl: thumbnailUrl,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await _db.collection('courses').doc(courseId).set(course.toFirestore());
      return courseId;
    } catch (e) {
      debugPrint('Error creating course: $e');
      return null;
    }
  }

  /// Update course details
  Future<bool> updateCourse({
    required String courseId,
    String? title,
    String? description,
    File? thumbnailFile,
    bool? isPublished,
  }) async {
    try {
      final updates = <String, dynamic>{
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      };

      if (title != null) updates['title'] = title;
      if (description != null) updates['description'] = description;
      if (isPublished != null) updates['isPublished'] = isPublished;

      if (thumbnailFile != null) {
        updates['thumbnailUrl'] = await _uploadFile(
          file: thumbnailFile,
          path: 'course_thumbnails/$courseId.jpg',
          contentType: 'image/jpeg',
        );
      }

      await _db.collection('courses').doc(courseId).update(updates);
      return true;
    } catch (e) {
      debugPrint('Error updating course: $e');
      return false;
    }
  }

  /// Delete a course and all its content
  Future<bool> deleteCourse(String courseId) async {
    try {
      // Delete all lectures
      final lectures = await _db
          .collection('lectures')
          .where('courseId', isEqualTo: courseId)
          .get();
      for (final doc in lectures.docs) {
        await doc.reference.delete();
      }

      // Delete all attachments
      final attachments = await _db
          .collection('attachments')
          .where('courseId', isEqualTo: courseId)
          .get();
      for (final doc in attachments.docs) {
        await doc.reference.delete();
      }

      // Delete the course
      await _db.collection('courses').doc(courseId).delete();
      return true;
    } catch (e) {
      debugPrint('Error deleting course: $e');
      return false;
    }
  }

  // ─── Lectures ─────────────────────────────────────────────────────────────────

  /// Stream lectures for a course, ordered by index
  Stream<List<LectureModel>> getLecturesStream(String courseId) {
    return _db
        .collection('lectures')
        .where('courseId', isEqualTo: courseId)
        .orderBy('orderIndex')
        .snapshots()
        .map((snap) => snap.docs.map(LectureModel.fromFirestore).toList());
  }

  /// Upload a video lecture to Firebase Storage and save metadata
  Future<String?> uploadLecture({
    required String courseId,
    required String title,
    String? description,
    required File videoFile,
    required int orderIndex,
    Function(double)? onProgress,
  }) async {
    try {
      final lectureId = _uuid.v4();
      final ext = videoFile.path.split('.').last;
      final storagePath = 'lectures/$courseId/$lectureId.$ext';

      // Upload video with progress tracking
      final videoUrl = await _uploadFile(
        file: videoFile,
        path: storagePath,
        contentType: 'video/mp4',
        onProgress: onProgress,
      );

      if (videoUrl == null) return null;

      final lecture = LectureModel(
        id: lectureId,
        courseId: courseId,
        title: title,
        description: description,
        videoUrl: videoUrl,
        orderIndex: orderIndex,
        createdAt: DateTime.now(),
      );

      await _db
          .collection('lectures')
          .doc(lectureId)
          .set(lecture.toFirestore());
      return lectureId;
    } catch (e) {
      debugPrint('Error uploading lecture: $e');
      return null;
    }
  }

  /// Delete a lecture
  Future<bool> deleteLecture(String lectureId) async {
    try {
      await _db.collection('lectures').doc(lectureId).delete();
      return true;
    } catch (e) {
      debugPrint('Error deleting lecture: $e');
      return false;
    }
  }

  // ─── Attachments ──────────────────────────────────────────────────────────────

  /// Stream attachments for a course
  Stream<List<AttachmentModel>> getAttachmentsStream(String courseId) {
    return _db
        .collection('attachments')
        .where('courseId', isEqualTo: courseId)
        .snapshots()
        .map((snap) => snap.docs.map(AttachmentModel.fromFirestore).toList());
  }

  /// Upload a PDF or file attachment
  Future<String?> uploadAttachment({
    required String courseId,
    required String title,
    required File file,
    required String fileType,
  }) async {
    try {
      final attachmentId = _uuid.v4();
      final ext = file.path.split('.').last;
      final storagePath = 'attachments/$courseId/$attachmentId.$ext';

      final fileUrl = await _uploadFile(
        file: file,
        path: storagePath,
        contentType: 'application/pdf',
      );

      if (fileUrl == null) return null;

      final fileSizeBytes = await file.length();
      final attachment = AttachmentModel(
        id: attachmentId,
        courseId: courseId,
        title: title,
        fileUrl: fileUrl,
        fileType: fileType,
        fileSizeBytes: fileSizeBytes,
        createdAt: DateTime.now(),
      );

      await _db
          .collection('attachments')
          .doc(attachmentId)
          .set(attachment.toFirestore());
      return attachmentId;
    } catch (e) {
      debugPrint('Error uploading attachment: $e');
      return null;
    }
  }

  // ─── Course Access ────────────────────────────────────────────────────────────

  /// Check if a student has access to a course
  Future<bool> hasAccess({
    required String studentId,
    required String courseId,
  }) async {
    try {
      final doc = await _db
          .collection('course_access')
          .doc('${studentId}_$courseId')
          .get();
      if (!doc.exists) return false;
      final data = doc.data() as Map<String, dynamic>;
      return data['hasAccess'] == true;
    } catch (e) {
      return false;
    }
  }

  /// Stream access status for real-time updates
  Stream<bool> accessStream({
    required String studentId,
    required String courseId,
  }) {
    return _db
        .collection('course_access')
        .doc('${studentId}_$courseId')
        .snapshots()
        .map((doc) {
      if (!doc.exists) return false;
      final data = doc.data() as Map<String, dynamic>;
      return data['hasAccess'] == true;
    });
  }

  /// Request access to a course (creates pending record)
  Future<bool> requestAccess({
    required String studentId,
    required String courseId,
  }) async {
    try {
      await _db
          .collection('course_access')
          .doc('${studentId}_$courseId')
          .set(CourseAccessModel(
            id: '${studentId}_$courseId',
            studentId: studentId,
            courseId: courseId,
            hasAccess: false,
            grantedAt: DateTime.now(),
            grantedBy: 'pending',
          ).toFirestore());
      return true;
    } catch (e) {
      return false;
    }
  }

  // ─── Watch Progress ───────────────────────────────────────────────────────────

  /// Update watch progress for a lecture
  Future<void> updateWatchProgress({
    required String studentId,
    required String lectureId,
    required String courseId,
    required int watchedSeconds,
    required int totalSeconds,
  }) async {
    try {
      final docId = '${studentId}_$lectureId';
      final isCompleted =
          totalSeconds > 0 && watchedSeconds >= totalSeconds * 0.9;

      await _db.collection('watch_progress').doc(docId).set({
        'studentId': studentId,
        'lectureId': lectureId,
        'courseId': courseId,
        'watchedSeconds': watchedSeconds,
        'isCompleted': isCompleted,
        'lastWatched': Timestamp.fromDate(DateTime.now()),
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint('Error updating watch progress: $e');
    }
  }

  /// Stream watch progress for student's lectures in a course
  Stream<List<WatchProgressModel>> getWatchProgressStream({
    required String studentId,
    required String courseId,
  }) {
    return _db
        .collection('watch_progress')
        .where('studentId', isEqualTo: studentId)
        .where('courseId', isEqualTo: courseId)
        .snapshots()
        .map((snap) =>
            snap.docs.map(WatchProgressModel.fromFirestore).toList());
  }

  // ─── Enrolled Students ────────────────────────────────────────────────────────

  /// Stream students enrolled in a teacher's course
  Stream<List<Map<String, dynamic>>> getEnrolledStudentsStream(
      String courseId) {
    return _db
        .collection('course_access')
        .where('courseId', isEqualTo: courseId)
        .where('hasAccess', isEqualTo: true)
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => d.data() as Map<String, dynamic>)
            .toList());
  }

  // ─── File Upload Helper ───────────────────────────────────────────────────────

  Future<String?> _uploadFile({
    required File file,
    required String path,
    required String contentType,
    Function(double)? onProgress,
  }) async {
    try {
      final ref = _storage.ref(path);
      final metadata = SettableMetadata(contentType: contentType);
      final uploadTask = ref.putFile(file, metadata);

      if (onProgress != null) {
        uploadTask.snapshotEvents.listen((snapshot) {
          final progress =
              snapshot.bytesTransferred / snapshot.totalBytes;
          onProgress(progress);
        });
      }

      final snapshot = await uploadTask;
      return await snapshot.ref.getDownloadURL();
    } catch (e) {
      debugPrint('File upload error: $e');
      return null;
    }
  }
}
