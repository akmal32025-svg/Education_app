import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import '../models/user_model.dart';

/// Handles all Firebase Authentication logic including
/// single-device enforcement and user profile management.
class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();

  // ─── Current User ────────────────────────────────────────────────────────────

  User? get currentFirebaseUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Get current user's Firestore profile
  Future<UserModel?> getCurrentUserProfile() async {
    final user = _auth.currentUser;
    if (user == null) return null;
    return getUserById(user.uid);
  }

  /// Fetch any user profile by UID
  Future<UserModel?> getUserById(String uid) async {
    try {
      final doc = await _db.collection('users').doc(uid).get();
      if (!doc.exists) return null;
      return UserModel.fromFirestore(doc);
    } catch (e) {
      debugPrint('Error fetching user: $e');
      return null;
    }
  }

  // ─── Device ID ───────────────────────────────────────────────────────────────

  /// Returns a unique device identifier for single-device login enforcement
  Future<String> getDeviceId() async {
    try {
      if (defaultTargetPlatform == TargetPlatform.android) {
        final info = await _deviceInfo.androidInfo;
        return info.id; // Android device ID
      } else if (defaultTargetPlatform == TargetPlatform.iOS) {
        final info = await _deviceInfo.iosInfo;
        return info.identifierForVendor ?? 'unknown-ios';
      }
      return 'unknown-platform';
    } catch (e) {
      return 'unknown-device';
    }
  }

  // ─── Registration ─────────────────────────────────────────────────────────────

  /// Register a new user with email, password, name, and role.
  Future<AuthResult> register({
    required String email,
    required String password,
    required String displayName,
    required String role, // 'student' | 'teacher'
  }) async {
    try {
      // Create Firebase Auth account
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final uid = credential.user!.uid;
      final deviceId = await getDeviceId();

      // Build user profile
      final userModel = UserModel(
        uid: uid,
        email: email,
        displayName: displayName,
        role: role,
        deviceId: deviceId,
        createdAt: DateTime.now(),
      );

      // Save to Firestore
      await _db.collection('users').doc(uid).set(userModel.toFirestore());

      // Update Firebase display name
      await credential.user!.updateDisplayName(displayName);

      return AuthResult.success(userModel);
    } on FirebaseAuthException catch (e) {
      return AuthResult.failure(_mapAuthError(e.code));
    } catch (e) {
      return AuthResult.failure('An unexpected error occurred.');
    }
  }

  // ─── Login ────────────────────────────────────────────────────────────────────

  /// Login with single-device enforcement.
  Future<AuthResult> login({
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      final uid = credential.user!.uid;
      final deviceId = await getDeviceId();

      // Fetch user profile
      final doc = await _db.collection('users').doc(uid).get();
      if (!doc.exists) {
        await _auth.signOut();
        return AuthResult.failure('User profile not found.');
      }

      final userModel = UserModel.fromFirestore(doc);

      // 🔐 SECURITY: Single-device enforcement
      // If a device ID is stored and it doesn't match current device → block
      if (userModel.deviceId.isNotEmpty &&
          userModel.deviceId != deviceId &&
          userModel.deviceId != 'unknown-device') {
        await _auth.signOut();
        return AuthResult.deviceConflict(
          'This account is already active on another device.',
        );
      }

      // Update device ID if changed or empty
      if (userModel.deviceId != deviceId) {
        await _db.collection('users').doc(uid).update({'deviceId': deviceId});
      }

      return AuthResult.success(userModel);
    } on FirebaseAuthException catch (e) {
      return AuthResult.failure(_mapAuthError(e.code));
    } catch (e) {
      return AuthResult.failure('An unexpected error occurred.');
    }
  }

  // ─── Sign Out ─────────────────────────────────────────────────────────────────

  Future<void> signOut() async {
    await _auth.signOut();
  }

  // ─── Profile Update ───────────────────────────────────────────────────────────

  Future<bool> updateProfile({
    required String uid,
    String? displayName,
    String? bio,
    String? subject,
    String? photoUrl,
  }) async {
    try {
      final updates = <String, dynamic>{};
      if (displayName != null) updates['displayName'] = displayName;
      if (bio != null) updates['bio'] = bio;
      if (subject != null) updates['subject'] = subject;
      if (photoUrl != null) updates['photoUrl'] = photoUrl;

      await _db.collection('users').doc(uid).update(updates);
      return true;
    } catch (e) {
      debugPrint('Error updating profile: $e');
      return false;
    }
  }

  // ─── Teachers List ────────────────────────────────────────────────────────────

  Stream<List<UserModel>> getTeachersStream() {
    return _db
        .collection('users')
        .where('role', isEqualTo: 'teacher')
        .where('isActive', isEqualTo: true)
        .snapshots()
        .map((snap) => snap.docs.map(UserModel.fromFirestore).toList());
  }

  // ─── Error Mapping ────────────────────────────────────────────────────────────

  String _mapAuthError(String code) {
    switch (code) {
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password. Please try again.';
      case 'email-already-in-use':
        return 'An account already exists with this email.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';
      case 'network-request-failed':
        return 'Network error. Check your internet connection.';
      default:
        return 'Authentication failed. Please try again.';
    }
  }
}

// ─── Auth Result ──────────────────────────────────────────────────────────────

/// Result wrapper for authentication operations
class AuthResult {
  final bool isSuccess;
  final bool isDeviceConflict;
  final UserModel? user;
  final String? error;

  const AuthResult._({
    required this.isSuccess,
    required this.isDeviceConflict,
    this.user,
    this.error,
  });

  factory AuthResult.success(UserModel user) => AuthResult._(
        isSuccess: true,
        isDeviceConflict: false,
        user: user,
      );

  factory AuthResult.failure(String error) => AuthResult._(
        isSuccess: false,
        isDeviceConflict: false,
        error: error,
      );

  factory AuthResult.deviceConflict(String message) => AuthResult._(
        isSuccess: false,
        isDeviceConflict: true,
        error: message,
      );
}
