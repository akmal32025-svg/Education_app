import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';
import '../../models/lecture_model.dart';
import '../../services/course_service.dart';
import '../../main.dart';

/// Secure video player screen.
/// Videos are streamed from Firebase Storage — no download option.
class VideoPlayerScreen extends StatefulWidget {
  final LectureModel lecture;
  final String studentId;
  final String courseId;

  const VideoPlayerScreen({
    super.key,
    required this.lecture,
    required this.studentId,
    required this.courseId,
  });

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  final _courseService = CourseService();

  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';

  // Track playback for progress saving
  int _lastSavedSecond = 0;

  @override
  void initState() {
    super.initState();
    // Force landscape for video playback
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
      DeviceOrientation.portraitUp,
    ]);
    _initPlayer();
  }

  @override
  void dispose() {
    // Save final progress
    _saveProgress();

    // Restore portrait-only orientation
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);

    _chewieController?.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _initPlayer() async {
    try {
      // Stream from Firebase Storage URL — no local download
      _videoController = VideoPlayerController.networkUrl(
        Uri.parse(widget.lecture.videoUrl),
      );

      await _videoController!.initialize();

      _chewieController = ChewieController(
        videoPlayerController: _videoController!,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowMuting: true,
        showOptions: false, // Disable download/share options
        allowPlaybackSpeedChanging: true,
        // 🔐 SECURITY: No download button
        additionalOptions: (_) => [],
        customControls: const MaterialControls(),
        placeholder: Container(color: Colors.black),
        errorBuilder: (context, errorMessage) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, color: Colors.red, size: 48),
              const SizedBox(height: 12),
              Text(errorMessage, style: const TextStyle(color: Colors.white)),
            ],
          ),
        ),
      );

      // Listen to position for progress tracking
      _videoController!.addListener(_onVideoProgress);

      if (mounted) {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _hasError = true;
          _errorMessage = 'Failed to load video. Please try again.';
        });
      }
    }
  }

  void _onVideoProgress() {
    if (_videoController == null) return;
    final position =
        _videoController!.value.position.inSeconds;

    // Save progress every 10 seconds
    if (position - _lastSavedSecond >= 10) {
      _lastSavedSecond = position;
      _saveProgress();
    }
  }

  Future<void> _saveProgress() async {
    if (_videoController == null) return;
    final position = _videoController!.value.position.inSeconds;
    final total = _videoController!.value.duration.inSeconds;

    if (position > 0) {
      await _courseService.updateWatchProgress(
        studentId: widget.studentId,
        lectureId: widget.lecture.id,
        courseId: widget.courseId,
        watchedSeconds: position,
        totalSeconds: total,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          widget.lecture.title,
          style: const TextStyle(fontSize: 15),
        ),
        actions: [
          // 🔐 No download button shown intentionally
          const Padding(
            padding: EdgeInsets.only(right: 12),
            child: Icon(Icons.lock_outline, color: Colors.white60, size: 18),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Video Player
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: CircularProgressIndicator(color: Colors.white))
                  : _hasError
                      ? Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.error_outline,
                                  color: Colors.red, size: 48),
                              const SizedBox(height: 12),
                              Text(
                                _errorMessage,
                                style: const TextStyle(color: Colors.white),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 20),
                              ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    _isLoading = true;
                                    _hasError = false;
                                  });
                                  _initPlayer();
                                },
                                child: const Text('Retry'),
                              ),
                            ],
                          ),
                        )
                      : Chewie(controller: _chewieController!),
            ),

            // Lecture Info
            Container(
              color: const Color(0xFF1A1A2E),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.lecture.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  if (widget.lecture.description != null) ...[
                    const SizedBox(height: 6),
                    Text(
                      widget.lecture.description!,
                      style:
                          TextStyle(color: Colors.white.withOpacity(0.7)),
                    ),
                  ],
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.security,
                          size: 14, color: Colors.white38),
                      const SizedBox(width: 4),
                      Text(
                        'Secure streaming — no download available',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.4),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
