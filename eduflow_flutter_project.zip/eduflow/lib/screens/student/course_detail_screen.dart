import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../models/user_model.dart';
import '../../models/course_model.dart';
import '../../models/lecture_model.dart';
import '../../services/course_service.dart';
import '../../main.dart';
import 'video_player_screen.dart';

/// Course detail screen where students view lectures and request access
class CourseDetailScreen extends StatefulWidget {
  final CourseModel course;
  final UserModel student;

  const CourseDetailScreen({
    super.key,
    required this.course,
    required this.student,
  });

  @override
  State<CourseDetailScreen> createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends State<CourseDetailScreen> {
  final _courseService = CourseService();
  bool _hasAccess = false;
  bool _checkingAccess = true;

  @override
  void initState() {
    super.initState();
    _checkAccess();
  }

  Future<void> _checkAccess() async {
    final access = await _courseService.hasAccess(
      studentId: widget.student.uid,
      courseId: widget.course.id,
    );
    if (mounted) {
      setState(() {
        _hasAccess = access;
        _checkingAccess = false;
      });
    }
  }

  /// Opens Telegram for manual payment/access request
  Future<void> _openTelegramForPurchase() async {
    // Replace with your admin's Telegram username
    const telegramUsername = 'YourAdminUsername';
    final message =
        'Hi! I want to enroll in "${widget.course.title}". My User ID: ${widget.student.uid}';
    final encoded = Uri.encodeComponent(message);
    final url =
        Uri.parse('https://t.me/$telegramUsername?text=$encoded');

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);

      // Create pending access record
      await _courseService.requestAccess(
        studentId: widget.student.uid,
        courseId: widget.course.id,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
                '✅ Request sent! Access will be activated after payment confirmation.'),
            backgroundColor: AppTheme.success,
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Could not open Telegram. Please install it.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: CustomScrollView(
        slivers: [
          // Hero header with thumbnail
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            leading: CircleAvatar(
              backgroundColor: Colors.black38,
              child: IconButton(
                icon:
                    const Icon(Icons.arrow_back_ios_new, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: widget.course.thumbnailUrl != null
                  ? CachedNetworkImage(
                      imageUrl: widget.course.thumbnailUrl!,
                      fit: BoxFit.cover,
                      errorWidget: (_, __, ___) => _defaultThumbnail(),
                    )
                  : _defaultThumbnail(),
            ),
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title
                      Text(
                        widget.course.title,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.textDark,
                        ),
                      ),
                      const SizedBox(height: 6),

                      // Teacher
                      Row(
                        children: [
                          const Icon(Icons.person_outline,
                              size: 18, color: AppTheme.textGrey),
                          const SizedBox(width: 4),
                          Text(
                            widget.course.teacherName,
                            style: const TextStyle(color: AppTheme.textGrey),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // Access banner
                      _checkingAccess
                          ? const LinearProgressIndicator()
                          : _hasAccess
                              ? Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: AppTheme.success.withOpacity(0.12),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                        color: AppTheme.success
                                            .withOpacity(0.4)),
                                  ),
                                  child: const Row(
                                    children: [
                                      Icon(Icons.check_circle_outline,
                                          color: AppTheme.success),
                                      SizedBox(width: 8),
                                      Text(
                                        'You have full access to this course!',
                                        style: TextStyle(
                                            color: AppTheme.success,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ],
                                  ),
                                )
                              : ElevatedButton.icon(
                                  onPressed: _openTelegramForPurchase,
                                  icon: const Icon(Icons.telegram),
                                  label: const Text('Buy Course via Telegram'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF0088CC),
                                    minimumSize:
                                        const Size(double.infinity, 50),
                                  ),
                                ),

                      const SizedBox(height: 20),

                      // Description
                      const Text(
                        'About This Course',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textDark,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        widget.course.description,
                        style: const TextStyle(
                          color: AppTheme.textGrey,
                          height: 1.6,
                        ),
                      ),
                    ],
                  ),
                ),

                // Lectures Section
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: const Text(
                    'Lectures',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textDark,
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                StreamBuilder<List<LectureModel>>(
                  stream:
                      _courseService.getLecturesStream(widget.course.id),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Padding(
                        padding: EdgeInsets.all(20),
                        child: CircularProgressIndicator(),
                      );
                    }

                    final lectures = snapshot.data ?? [];
                    if (lectures.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.all(20),
                        child: Text('No lectures uploaded yet.'),
                      );
                    }

                    return ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: lectures.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 8),
                      itemBuilder: (context, index) {
                        final lecture = lectures[index];
                        return _LectureTile(
                          lecture: lecture,
                          index: index,
                          hasAccess: _hasAccess,
                          onTap: () {
                            if (_hasAccess) {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => VideoPlayerScreen(
                                    lecture: lecture,
                                    studentId: widget.student.uid,
                                    courseId: widget.course.id,
                                  ),
                                ),
                              );
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                      '🔒 Purchase this course to watch lectures.'),
                                ),
                              );
                            }
                          },
                        );
                      },
                    );
                  },
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _defaultThumbnail() {
    return Container(
      color: AppTheme.primary.withOpacity(0.8),
      child: const Center(
        child: Icon(Icons.play_circle_fill, size: 64, color: Colors.white),
      ),
    );
  }
}

// ─── Lecture Tile ─────────────────────────────────────────────────────────────

class _LectureTile extends StatelessWidget {
  final LectureModel lecture;
  final int index;
  final bool hasAccess;
  final VoidCallback onTap;

  const _LectureTile({
    required this.lecture,
    required this.index,
    required this.hasAccess,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: hasAccess
                ? AppTheme.primary.withOpacity(0.15)
                : Colors.grey.shade200,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: hasAccess
                ? const Icon(Icons.play_arrow_rounded,
                    color: AppTheme.primary)
                : const Icon(Icons.lock_outline,
                    color: AppTheme.textGrey, size: 20),
          ),
        ),
        title: Text(
          lecture.title,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          'Lecture ${index + 1}',
          style: const TextStyle(color: AppTheme.textGrey, fontSize: 12),
        ),
        trailing: hasAccess
            ? const Icon(Icons.chevron_right, color: AppTheme.textGrey)
            : null,
        onTap: onTap,
      ),
    );
  }
}
