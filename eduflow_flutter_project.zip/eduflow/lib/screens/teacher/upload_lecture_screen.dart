import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../models/course_model.dart';
import '../../services/course_service.dart';
import '../../main.dart';

/// Screen for teachers to upload video lectures
class UploadLectureScreen extends StatefulWidget {
  final CourseModel course;

  const UploadLectureScreen({super.key, required this.course});

  @override
  State<UploadLectureScreen> createState() => _UploadLectureScreenState();
}

class _UploadLectureScreenState extends State<UploadLectureScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _courseService = CourseService();

  File? _videoFile;
  String? _videoFileName;
  bool _isUploading = false;
  double _uploadProgress = 0;
  String _uploadStatus = '';

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickVideo() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.video,
      allowMultiple: false,
    );

    if (result != null && result.files.single.path != null) {
      setState(() {
        _videoFile = File(result.files.single.path!);
        _videoFileName = result.files.single.name;
      });
    }
  }

  Future<void> _uploadLecture() async {
    if (!_formKey.currentState!.validate()) return;
    if (_videoFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a video file')),
      );
      return;
    }

    setState(() {
      _isUploading = true;
      _uploadProgress = 0;
      _uploadStatus = 'Uploading video...';
    });

    // Get current lecture count for ordering
    final lectureId = await _courseService.uploadLecture(
      courseId: widget.course.id,
      title: _titleCtrl.text.trim(),
      description: _descCtrl.text.trim().isNotEmpty
          ? _descCtrl.text.trim()
          : null,
      videoFile: _videoFile!,
      orderIndex: DateTime.now().millisecondsSinceEpoch,
      onProgress: (progress) {
        setState(() {
          _uploadProgress = progress;
          _uploadStatus =
              'Uploading... ${(progress * 100).toStringAsFixed(0)}%';
        });
      },
    );

    if (!mounted) return;
    setState(() {
      _isUploading = false;
      _uploadStatus = '';
    });

    if (lectureId != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Lecture uploaded successfully!'),
          backgroundColor: AppTheme.success,
        ),
      );
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Upload failed. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Upload Lecture')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Course info card
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.book_outlined, color: AppTheme.primary),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        widget.course.title,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: AppTheme.primary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Video picker
              GestureDetector(
                onTap: _isUploading ? null : _pickVideo,
                child: Container(
                  height: 140,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _videoFile != null
                          ? AppTheme.success
                          : Colors.grey.shade200,
                      width: 2,
                    ),
                  ),
                  child: _videoFile == null
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.video_call_outlined,
                                size: 48, color: Colors.grey.shade400),
                            const SizedBox(height: 8),
                            Text(
                              'Tap to select video',
                              style:
                                  TextStyle(color: Colors.grey.shade500),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'MP4, MOV, AVI supported',
                              style: TextStyle(
                                color: Colors.grey.shade400,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.check_circle,
                                size: 40, color: AppTheme.success),
                            const SizedBox(height: 8),
                            Text(
                              _videoFileName ?? 'Video selected',
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                color: AppTheme.success,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            TextButton(
                              onPressed: _pickVideo,
                              child: const Text('Change video'),
                            ),
                          ],
                        ),
                ),
              ),
              const SizedBox(height: 20),

              // Title field
              TextFormField(
                controller: _titleCtrl,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                  labelText: 'Lecture Title',
                  prefixIcon: Icon(Icons.title),
                ),
                validator: (v) =>
                    (v?.isEmpty ?? true) ? 'Title is required' : null,
              ),
              const SizedBox(height: 14),

              // Description
              TextFormField(
                controller: _descCtrl,
                maxLines: 3,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                  labelText: 'Description (optional)',
                  prefixIcon: Icon(Icons.description_outlined),
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 24),

              // Upload progress
              if (_isUploading) ...[
                Text(
                  _uploadStatus,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppTheme.textGrey),
                ),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: _uploadProgress,
                    backgroundColor: Colors.grey.shade200,
                    color: AppTheme.primary,
                    minHeight: 8,
                  ),
                ),
                const SizedBox(height: 16),
              ],

              // Upload button
              ElevatedButton.icon(
                onPressed: _isUploading ? null : _uploadLecture,
                icon: _isUploading
                    ? const SizedBox(
                        height: 18,
                        width: 18,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2),
                      )
                    : const Icon(Icons.upload_rounded),
                label: Text(_isUploading ? 'Uploading...' : 'Upload Lecture'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
