import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../models/user_model.dart';
import '../../models/course_model.dart';
import '../../models/lecture_model.dart';
import '../../services/course_service.dart';
import '../../main.dart';
import 'upload_lecture_screen.dart';

/// Teacher course management — view lectures, upload content, see enrolled students
class TeacherCourseScreen extends StatefulWidget {
  final CourseModel course;
  final UserModel teacher;

  const TeacherCourseScreen({
    super.key,
    required this.course,
    required this.teacher,
  });

  @override
  State<TeacherCourseScreen> createState() => _TeacherCourseScreenState();
}

class _TeacherCourseScreenState extends State<TeacherCourseScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _courseService = CourseService();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: Text(widget.course.title),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(text: 'Lectures'),
            Tab(text: 'Attachments'),
            Tab(text: 'Students'),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'delete') _confirmDelete();
              if (v == 'toggle') _togglePublish();
            },
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'toggle',
                child: Row(children: [
                  Icon(widget.course.isPublished
                      ? Icons.visibility_off
                      : Icons.visibility),
                  const SizedBox(width: 8),
                  Text(widget.course.isPublished ? 'Unpublish' : 'Publish'),
                ]),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Row(children: [
                  Icon(Icons.delete_outline, color: Colors.red),
                  SizedBox(width: 8),
                  Text('Delete Course',
                      style: TextStyle(color: Colors.red)),
                ]),
              ),
            ],
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _LecturesTab(
              course: widget.course, courseService: _courseService),
          _AttachmentsTab(
              course: widget.course, courseService: _courseService),
          _StudentsTab(
              course: widget.course, courseService: _courseService),
        ],
      ),
    );
  }

  void _confirmDelete() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Course?'),
        content: const Text(
            'This will permanently delete the course and all its content.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await _courseService.deleteCourse(widget.course.id);
              if (mounted) Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _togglePublish() async {
    await _courseService.updateCourse(
      courseId: widget.course.id,
      isPublished: !widget.course.isPublished,
    );
    if (mounted) Navigator.pop(context);
  }
}

// ─── Lectures Tab ─────────────────────────────────────────────────────────────

class _LecturesTab extends StatelessWidget {
  final CourseModel course;
  final CourseService courseService;

  const _LecturesTab({required this.course, required this.courseService});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => UploadLectureScreen(course: course),
          ),
        ),
        backgroundColor: AppTheme.primary,
        icon: const Icon(Icons.video_call_outlined),
        label: const Text('Add Lecture'),
      ),
      body: StreamBuilder<List<LectureModel>>(
        stream: courseService.getLecturesStream(course.id),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final lectures = snapshot.data ?? [];
          if (lectures.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.video_library_outlined,
                      size: 64, color: Colors.grey.shade300),
                  const SizedBox(height: 12),
                  const Text('No lectures yet'),
                ],
              ),
            );
          }

          return ReorderableListView.builder(
            padding:
                const EdgeInsets.fromLTRB(16, 16, 16, 80),
            itemCount: lectures.length,
            onReorder: (_, __) {}, // TODO: implement reorder
            itemBuilder: (context, index) {
              final lecture = lectures[index];
              return Card(
                key: ValueKey(lecture.id),
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.12),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text(
                        '${index + 1}',
                        style: const TextStyle(
                          color: AppTheme.primary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  title: Text(lecture.title,
                      style:
                          const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(
                    lecture.description ?? 'No description',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: AppTheme.textGrey, fontSize: 12),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline,
                        color: Colors.red),
                    onPressed: () => _confirmDeleteLecture(
                        context, lecture.id, lecture.title),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _confirmDeleteLecture(
      BuildContext context, String lectureId, String title) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Lecture?'),
        content: Text('Delete "$title"?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await courseService.deleteLecture(lectureId);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

// ─── Attachments Tab ──────────────────────────────────────────────────────────

class _AttachmentsTab extends StatefulWidget {
  final CourseModel course;
  final CourseService courseService;

  const _AttachmentsTab(
      {required this.course, required this.courseService});

  @override
  State<_AttachmentsTab> createState() => _AttachmentsTabState();
}

class _AttachmentsTabState extends State<_AttachmentsTab> {
  bool _isUploading = false;
  double _uploadProgress = 0;

  Future<void> _pickAndUploadFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx', 'ppt', 'pptx'],
    );

    if (result == null || result.files.single.path == null) return;

    final file = File(result.files.single.path!);
    final name = result.files.single.name;
    final ext = name.split('.').last.toLowerCase();

    setState(() {
      _isUploading = true;
      _uploadProgress = 0;
    });

    await widget.courseService.uploadAttachment(
      courseId: widget.course.id,
      title: name,
      file: file,
      fileType: ext,
    );

    if (mounted) {
      setState(() => _isUploading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ File uploaded successfully!'),
          backgroundColor: AppTheme.success,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isUploading ? null : _pickAndUploadFile,
        backgroundColor: AppTheme.primary,
        icon: const Icon(Icons.attach_file),
        label: const Text('Upload File'),
      ),
      body: Column(
        children: [
          if (_isUploading)
            LinearProgressIndicator(value: _uploadProgress),
          Expanded(
            child: StreamBuilder<List<AttachmentModel>>(
              stream:
                  widget.courseService.getAttachmentsStream(widget.course.id),
              builder: (context, snapshot) {
                final attachments = snapshot.data ?? [];
                if (attachments.isEmpty) {
                  return const Center(child: Text('No attachments yet'));
                }

                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
                  itemCount: attachments.length,
                  itemBuilder: (context, index) {
                    final a = attachments[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        leading: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: Colors.red.shade50,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(Icons.picture_as_pdf,
                              color: Colors.red.shade400),
                        ),
                        title: Text(a.title,
                            style: const TextStyle(
                                fontWeight: FontWeight.w600)),
                        subtitle: Text(a.formattedSize),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Students Tab ─────────────────────────────────────────────────────────────

class _StudentsTab extends StatelessWidget {
  final CourseModel course;
  final CourseService courseService;

  const _StudentsTab({required this.course, required this.courseService});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: courseService.getEnrolledStudentsStream(course.id),
      builder: (context, snapshot) {
        final students = snapshot.data ?? [];

        if (students.isEmpty) {
          return const Center(
            child: Text('No enrolled students yet'),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: students.length,
          itemBuilder: (context, index) {
            final s = students[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppTheme.primary.withOpacity(0.15),
                  child: const Icon(Icons.person, color: AppTheme.primary),
                ),
                title: Text(s['studentId'] ?? 'Unknown'),
                subtitle: const Text('Enrolled'),
                trailing: const Icon(Icons.check_circle,
                    color: AppTheme.success),
              ),
            );
          },
        );
      },
    );
  }
}
