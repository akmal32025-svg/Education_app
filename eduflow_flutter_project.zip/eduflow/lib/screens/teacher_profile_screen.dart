import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/user_model.dart';
import '../models/course_model.dart';
import '../services/course_service.dart';
import '../main.dart';
import '../widgets/course_card.dart';
import 'student/course_detail_screen.dart';

/// Public teacher profile — shows teacher info and their courses
class TeacherProfileScreen extends StatelessWidget {
  final UserModel teacher;
  final UserModel student;

  const TeacherProfileScreen({
    super.key,
    required this.teacher,
    required this.student,
  });

  @override
  Widget build(BuildContext context) {
    final courseService = CourseService();

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: CustomScrollView(
        slivers: [
          // Header
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppTheme.primaryDark, AppTheme.primary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 40),
                      CircleAvatar(
                        radius: 44,
                        backgroundColor: Colors.white.withOpacity(0.2),
                        backgroundImage: teacher.photoUrl != null
                            ? CachedNetworkImageProvider(teacher.photoUrl!)
                            : null,
                        child: teacher.photoUrl == null
                            ? Text(
                                teacher.displayName[0].toUpperCase(),
                                style: const TextStyle(
                                  fontSize: 32,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                ),
                              )
                            : null,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        teacher.displayName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      if (teacher.subject != null)
                        Text(
                          teacher.subject!,
                          style:
                              TextStyle(color: Colors.white.withOpacity(0.85)),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Body
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Bio
                if (teacher.bio != null && teacher.bio!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'About',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.textDark,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          teacher.bio!,
                          style: const TextStyle(
                            color: AppTheme.textGrey,
                            height: 1.6,
                          ),
                        ),
                      ],
                    ),
                  ),

                // Courses header
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                  child: const Text(
                    'Courses',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textDark,
                    ),
                  ),
                ),

                // Teacher's courses
                StreamBuilder<List<CourseModel>>(
                  stream: courseService.getTeacherCoursesStream(teacher.uid),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                          child: CircularProgressIndicator());
                    }

                    final courses = snapshot.data ?? [];
                    if (courses.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.all(20),
                        child: Text('No courses published yet.'),
                      );
                    }

                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        children: courses
                            .map((c) => CourseCard(
                                  course: c,
                                  onTap: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => CourseDetailScreen(
                                        course: c,
                                        student: student,
                                      ),
                                    ),
                                  ),
                                ))
                            .toList(),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
